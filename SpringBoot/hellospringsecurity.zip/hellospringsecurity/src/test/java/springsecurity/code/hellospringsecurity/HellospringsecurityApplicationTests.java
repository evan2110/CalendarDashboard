package springsecurity.code.hellospringsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellospringsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
